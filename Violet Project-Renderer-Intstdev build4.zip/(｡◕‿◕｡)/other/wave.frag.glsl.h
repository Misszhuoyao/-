
#include "shaders/uniformShaderConstants.h"
#include "shaders/uniformPerFrameConstants.h"
#include "shaders/uniformEntityConstants.h"

highp vec3 waves(vec3 w_pos,vec3 v_pos,vec2 uv0,vec2 uv1){

vec2 t_pos =floor(vec2(uv0.x * 64.0, uv0.y * 32.0));

float rain_f = (2.0-pow(FOG_CONTROL.y,2.0))*uv1.y;

highp vec3 wav_pos = vec3(0.0);

return vec3(0.0);
}
