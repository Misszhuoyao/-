❀❀<<<Shader file extension naming standard>>>>❀❀

- 以下我列举了一些常见的着色器文件扩展名，和社区的规范
- 这是不重要的，因为OpenGL程序的运行不需要这个。
- 所需求仅仅是语法高亮，此MCPE平台只是用JSON定义其文件名所在

.vert - 顶点着色器
.tesc - 曲面细分控制着色器～～
.tese - 曲面细分评估着色器～～
.geom - 几何着色器～～
.frag - 片元着色器
.comp - 计算着色器～～

Tessellation shaders ( hlsl ) - OpenGL 4.0, DirectX 3D 11
3D shaders
Vertex shaders
Pixel shaders ( hlsl ) - Fragment shaders ( glsl )
geometry shaders

object: 定义对象

object.fragment ( frag ) .glsl / object.glsl.fragment / object.glsl.frag
object.vertex ( vert ) .glsl / object.glsl.vertex / object.glsl.vert
object.fragment ( frag ) .hlsl / object.hlsl.fragment / object.hlsl.frag
object.vertex ( vert ) .hlsl / object.hlsl.vertex / object.hlsl.vert

common shading language.

.glsl - OpenGL.
.hlsl - High Level Shader Language Microsoft DirectX高级着色器语言

Here are some common shading language API info

OpenGL ( GLSL, GLSLANG ) 由OpenGL ARB创建的一个开放高级着色语言API，在C的基础上。

Direct 3D ( d3d ) - DirectX ( ...dx11, dx12 ) Microsoft

OpenGL ES ( OpenGL for Embedded Systems ) - ( OGL ES, GLSL ES ) API developed by Khronos Group

Khronos Group创建的以GLSL为原型移除部分机制的为嵌入式设备的API

Vulkan.~

.vsh - vertex shaders
.fsh - fragment shaders
.gsh
.tcsh
.tesh
.csh

- This file with hlsl or glsl as carrier.
- VSH and FSH file is a Microsoft DirectX D3D Vertex and Fragment Shaders.

-----common-----

object.fragment ( frag ).glsl ( .hlsl )
Object.vertex ( vert ).glsl ( .hlsl )

-----HLSL-----

.tessellationc - .tesc
.tessellatione - .tese
.geometry
.compute