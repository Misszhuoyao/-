/**
 * Created by IntelliJ IDEA.
 * User: Peter
 * Date: 2/5/12
 * Time: 2:31 PM
 * To change this template use File | Settings | File Templates.
 */
 
 
const int oct  = 8;
const float per  = 0.5;

highp float rand(highp vec2 p){ 
	return fract(cos(p.x* 625.61) * 618.552);
} 

float noisex(vec2 p){
    vec2 i = floor(p);
    vec2 f = fract(p);
    f = f* f* f*(3.0-2.0*f);
    
    vec4 v = vec4(
    rand(vec2(i.x,i.y)),
    rand(vec2(i.x + 1.0, i.y)),
    rand(vec2(i.x,i.y + 1.0)),
    rand(vec2(i.x + 1.0, i.y + 1.0)));
return 0.6+1.2*mix(mix(v.x, v.y, f.x), mix(v.z, v.w, f.x), f.y); }

highp float noise(highp vec2 p) { 
	highp vec2 i = floor(p); 
	highp vec2 f = fract(p);  
	highp vec2 u = f * f * (3.0 - 2.0 * f); 
	return -1.1 + 2.0 * mix(mix(rand(i + vec2(0.0, 0.0)), 
							rand(i + vec2(1.0, 0.0)), u.x), 
							mix(rand(i + vec2(0.0, 1.0)), 
							rand(i + vec2(1.0, 1.0)), u.x), u.y); 
}

highp float mixRand(vec2 p){
 highp float t = 0.0;
for(int i = 0; i < oct; i++){
 float freq = pow(2.0, float(i));
 float amp  = pow(per, float(oct - i));
t += noise(vec2(p.x / freq, p.y / freq)) * amp;
t += noisex(vec2(p.x / freq, p.y / freq)) * amp;
}
    return t; }
    
#define NUM_OCTAVES 9
#define NUM_PER 0.7

#define bl_0 0.0
#define bl_1 1.0
#define bl_2 2.0
#define bl_3 3.0

highp float rand(highp vec2 p){
    return fract(sin(dot(p,vec2(12.9898,78.233)))*43758.5453123);
}
/*
highp float noise(highp vec2 p) { 
	highp vec2 i = floor(p);
    highp vec2 f = fract(p);
	highp vec2 u =  f * f* (bl_3 - bl_2 * f);

  
    float a = rand(i);
    float b = rand(i + vec2(bl_1, bl_0));
    float c = rand(i + vec2(bl_0, bl_1));
    float d = rand(i + vec2(bl_1, bl_1));

    return mix(a, b, u.x) +
            (c - a)* u.y * (bl_1 - u.x) +
            (d - b) * u.x * u.y;
}

highp float mixRand(vec2 p){
 highp float t = bl_0;
for(int i = 0; i < NUM_OCTAVES; i++){
 float freq = pow(1.87, float(i));
 float amp  = pow(NUM_PER, float(NUM_OCTAVES - i));
t += noise(vec2(p.x / freq, p.y / freq)) * amp;
}
    return t; 
}

*/