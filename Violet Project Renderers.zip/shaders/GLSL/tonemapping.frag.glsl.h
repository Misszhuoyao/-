//Tonemapping Sources Code 0
vec3 ToneMapping(inout vec3 color) {

	const float A = 2.51;
	const float B = 0.03;
	const float C = 2.43;
	const float D = 0.59;
	const float E = 0.14;
	
	color = (color * (A * color + B)) / (color * (C * color + D) + E);
	color = clamp(pow(color.rgb, vec3(1.0 / 2.2)), vec3(0.0), vec3(1.0));

}

/*
//Tonemapping Sources Code 1
vec3 toneMapping(vec3 x){ 
	float A = 0.85;
	float B = 0.36;
	float C = 0.21;
	float D = 0.37;
	float E = 0.035;
	float F = 0.37;
return ((x*(A*x+C*B)+D*E)/(x*(A*x+B)+D*F))-E/F; 
}
*/